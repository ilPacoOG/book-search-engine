import typeDefs from './typeDefs.js';
import resolvers from './resolvers.js';

export { typeDefs, resolvers };

//taken directly from assignment 26
