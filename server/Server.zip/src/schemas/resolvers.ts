// resolvers taken from module 18, activity 26 and mofidifed

import User from '../models/User.js';
import { signToken } from '../services/auth.js';

const resolvers = {
  Query: {
    users: async () => {
      return User.find().populate('savedBooks');
    },
    user: async (_parent: any, { username }: { username: string }) => {
      return User.findOne({ username }).populate('savedBooks');
    },
    me: async (_parent: any, _args: any, context: any) => {
      if (context.user) {
        return User.findOne({ _id: context.user._id }).populate('savedBooks');
      }
      throw new Error('Could not authenticate user.');
    },
  },
  Mutation: {
    addUser: async (
      _parent: any,
      { username, email, password }: { username: string; email: string; password: string }
    ) => {
      // Create the user
      const user = await User.create({ username, email, password });
    
      // Generate a token
      const token = signToken(user.username, user.email, user._id);
    
      return { token, user };
    },
    
  
    login: async (_parent: any, { email, password }: { email: string; password: string }) => {
      const user = await User.findOne({ email });
      if (!user) {
        throw new Error('Could not authenticate user.');
      }
      const correctPw = await user.isCorrectPassword(password);
      if (!correctPw) {
        throw new Error('Could not authenticate user.');
      }
      const token = signToken(user.username, user.password, user.email);
      return { token, user };
    },
    saveBook: async (
      _parent: any,
      { bookId, authors, description, title, image, link }: 
      { bookId: string; authors: string[]; description: string; title: string; image: string; link: string },
      context: any
    ) => {
      if (context.user) {
        const updatedUser = await User.findByIdAndUpdate(
          context.user._id,
          {
            $addToSet: {
              savedBooks: { bookId, authors, description, title, image, link },
            },
          },
          { new: true }
        ).populate('savedBooks');
    
        return updatedUser;
      }
      throw new Error('You need to be logged in!');
    },
    
    removeBook: async (_parent: any, { bookId }: { bookId: string }, context: any) => {
      if (context.user) {
        const updatedUser = await User.findByIdAndUpdate(
          context.user._id,
          { $pull: { savedBooks: { bookId } } },
          { new: true }
        ).populate('savedBooks');
        return updatedUser;
      }
      throw new Error('You need to be logged in!');
    },
  },
};

export default resolvers;