import User from '../models/User';

export default { User };
